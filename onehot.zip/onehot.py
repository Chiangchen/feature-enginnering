#outher:Changchen  time:2018/9/12
#!/user/bin/env python
# -*-coding:utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,precision_recall_curve,average_precision_score,roc_curve,auc
#from sklearn.preorocessing import label_binarize
df = pd.read_csv('C:\\Users\Administrator\PycharmProjects\datahigher\car_data.csv',header=0,names=['buying','maint','doors','persons','lug_boot','safety','acceptance']
                 )
#print(df.head())
#print(df['acceptance'].value_counts())
buying_index = {'low':1,'med':2,'high':3,'vhigh':4}
main_index = {'med':1,'high':2,'low':3,'vhigh':4}
doors_index = {'2':1,'3':2,'4':3,'5more':4}
persons_index = {'2':1,'4':2,'more':3}
lug_boot_index = {'small':1,'med':2,'big':3}
safety_index = {'low':1,'med':2,'high':3}
acceptance_index = {'unacc':1,'acc':2,'good':3,'vgood':4}
df['buying']=df.buying.map(buying_index)
df['maint']=df.maint.map(main_index)
df['doors']=df.doors.map(doors_index)
df['persons']=df.persons.map(persons_index)
df['lug_boot']=df.lug_boot.map(lug_boot_index)
df['safety']=df.safety.map(safety_index)
df['acceptance']=df.acceptance.map(acceptance_index)
#print(df.head())
df_train = df.iloc[0:1382,]
df_test = df.iloc[1382:1728,]
#print(df_train.sample(5))
#print(df_test.sample(5))
df_train.drop(df_train.index[0],inplace=True)#在原数据修改删掉行
letter_recognition_model = SVC(C=1,kernel = "rbf")
letter_recognition_model.fit(df_train.iloc[:,:-1],df_train['acceptance'])
df_pred = letter_recognition_model.predict(df_test.iloc[:,:-1])
#print(classification_report(list(df_test["acceptance"]),list(df_pred)))
agreement = df_test["acceptance"]==df_pred
#print(agreement.value_counts())
#print("Accuracy:",accuracy_score(list(df_test['acceptance']),list(df_pred)))










