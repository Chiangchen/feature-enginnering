#outher:Changchen  time:2018/9/12
#!/user/bin/env python
# -*-coding:utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report,precision_recall_curve,average_precision_score,roc_curve,auc

df = pd.read_csv('C:\\Users\Administrator\PycharmProjects\datahigher\car_data.csv',header=0,names=['buying','maint','doors','persons','lug_boot','safety','acceptance'])
#print(df.head())

#标签列数字编码
params_list = {'unacc':1,'acc':2,'good':3,'vgood':4}
df['acceptance']=df['acceptance'].map(params_list)
#使用pandas包中get_dummies对数据框中一列进行onehot编码
dummies = pd.get_dummies(df["buying"],prefix="buying")
#print(dummies.head())
#axis=1,conact  就是行对齐，然后将不同列名称的两张表合并
df = pd.concat([df,dummies],axis=1)
#print(df)
dummies = pd.get_dummies(df["maint"],prefix="maint")
df = pd.concat([df,dummies],axis=1)
#print(df)
dummies = pd.get_dummies(df["doors"],prefix="doors")
df = pd.concat([df,dummies],axis=1)
dummies = pd.get_dummies(df["persons"],prefix="persons")
df = pd.concat([df,dummies],axis=1)
dummies = pd.get_dummies(df["lug_boot"],prefix="lug_boot")
df = pd.concat([df,dummies],axis=1)
dummies = pd.get_dummies(df["safety"],prefix="safety")
df = pd.concat([df,dummies],axis=1)
df_train = df.iloc[0:1500,]
df_test = df.iloc[1500:1728,]
letter_recognition_model = SVC(C=1,kernel='rbf')
letter_recognition_model.fit(df_train.iloc[:,7:],df_train['acceptance'].astype(int))
#print(df_train)
#print(df_train.iloc[:,7:])
df_pred= letter_recognition_model.predict(df_test.iloc[:,7:])
print(classification_report(list(df_test["acceptance"]),list(df_pred)))






